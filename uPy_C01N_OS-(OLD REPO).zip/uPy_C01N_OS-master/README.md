# uPy_C01N_OS
Updated: 24 June 2019

To get a basic flashing station make sure you have these dependencies

```
-> python3 
-> pip3
-> adafruit-ampy (through pip3)
-> esptool (through pip3)
```

Then get our stuff

```
git clone https://github.com/c01nrepo/uPy_C01N_OS.git
cd uPy_C01N_OS

chmod +x flash.sh

./flash.sh /dev/<yourC01Nlocation>
```

ragulbalaji hojiefeng andreng